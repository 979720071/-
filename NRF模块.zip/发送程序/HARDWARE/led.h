#ifndef _LED_H_
#define _LED_H_
#include "sys.h"

#define LED1 PCout(13)// PC13
//#define LED3 PDout(14)// PB14	

#include "stm32f10x.h"

void LED_Init(void);

#endif
