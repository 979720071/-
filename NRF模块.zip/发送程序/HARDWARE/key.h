#ifndef _KEY_H_
#define _KEY_H_

#include "stm32f10x.h"

#define KEY0 GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_0)
#define KEY1 GPIO_ReadInputDataBit(GPIOB, GPIO_Pin_1)

#define KEY0_PRESS	1
#define KEY1_PRESS  2

void KEY_Init(void);
unsigned char KEY_Scan(unsigned char mode);

#endif
