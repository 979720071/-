#include "led.h"

void LED_Init(void)
{
	GPIO_InitTypeDef GPIOINIT;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC, ENABLE);
	
	GPIOINIT.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIOINIT.GPIO_Pin = GPIO_Pin_13;
	GPIOINIT.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIOINIT);
	
	GPIO_ResetBits(GPIOC, GPIO_Pin_13);
}
