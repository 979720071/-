#include "led.h"

void LED_Init(void)
{
	GPIO_InitTypeDef GPIOINIT;
	RCC_APB2PeriphClockCmd(RCC_APB2Periph_GPIOC|RCC_APB2Periph_GPIOB, ENABLE);
	
	GPIOINIT.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIOINIT.GPIO_Pin = GPIO_Pin_13;
	GPIOINIT.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOC, &GPIOINIT);
	GPIO_ResetBits(GPIOC, GPIO_Pin_13);
	
	GPIOINIT.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIOINIT.GPIO_Pin = GPIO_Pin_9;
	GPIOINIT.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIOINIT);
	GPIO_ResetBits(GPIOB, GPIO_Pin_9);
	
	GPIOINIT.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIOINIT.GPIO_Pin = GPIO_Pin_8;
	GPIOINIT.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIOINIT);
	GPIO_ResetBits(GPIOB, GPIO_Pin_8);
	
	GPIOINIT.GPIO_Mode = GPIO_Mode_Out_PP;
	GPIOINIT.GPIO_Pin = GPIO_Pin_7;
	GPIOINIT.GPIO_Speed = GPIO_Speed_50MHz;
	GPIO_Init(GPIOB, &GPIOINIT);
	GPIO_ResetBits(GPIOB, GPIO_Pin_7);
	 
	
}
