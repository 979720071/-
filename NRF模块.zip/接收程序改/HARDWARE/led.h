#ifndef _LED_H_
#define _LED_H_
#include "sys.h"

#define LED1 PCout(13)// PC13
#define LED2 PBout(9)// PB9	
#define LED3 PBout(8)// PB8	
#define LED4 PBout(7)// PB7	
#include "stm32f10x.h"

void LED_Init(void);

#endif
